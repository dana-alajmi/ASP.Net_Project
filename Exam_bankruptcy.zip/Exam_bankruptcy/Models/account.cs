﻿using System.ComponentModel.DataAnnotations;

namespace Exam_bankruptcy.Models
{
    public class account
    {
        [Key]
        public int Id { get; set; }
        // ...

        [Required(ErrorMessage = "The Full Name field is required.")]
        [StringLength(20, MinimumLength = 3, ErrorMessage = " Full Name must be btween 3-20 characters .")]
        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Full Name can only contain letters and spaces.")]
        public string FullName { get; set; }
        // ...

        [Required(ErrorMessage = "The Email field is required.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]

        public string Email{ get; set; }
        // ...

        [Required(ErrorMessage = "The User Name field is required.")]
        [StringLength(10, MinimumLength = 5, ErrorMessage = "User Name must be between 5-10 characters.")]
        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "User Name can only contain letters and numbers.")]

        public string UserName{ get; set; }
        // ...

        [Required(ErrorMessage = "The Password field is required.")]
        [DataType(DataType.Password)]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters.")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{6,}$", ErrorMessage = "Password must include at least one uppercase letter, one lowercase letter, one digit, and one special character.")]
      
        public string Password { get; set; }
       

        
    }
}
