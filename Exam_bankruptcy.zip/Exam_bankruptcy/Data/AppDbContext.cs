﻿using Exam_bankruptcy.Models;
using Microsoft.EntityFrameworkCore;

namespace Exam_bankruptcy.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> Opations) : base(Opations)
        {
        }


        public DbSet<account> accounts { get; set; }
    }
}
