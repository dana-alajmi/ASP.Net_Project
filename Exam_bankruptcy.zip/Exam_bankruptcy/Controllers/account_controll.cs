﻿using Exam_bankruptcy.Data;
using Exam_bankruptcy.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using static System.Net.Mime.MediaTypeNames;

namespace Exam_bankruptcy.Controllers
{
    
    public class account_controll : Controller
    {
        private readonly AppDbContext _context;
        
            
        public account_controll(AppDbContext context)
        { _context = context; }
        public ActionResult Registera()
        { 

            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [Authorize]
        public ActionResult Indexhome()
        {
            return View("Indexhome");
        }
     
        [HttpPost]
        public IActionResult Registera(account registerdata)
        {
            if (registerdata.FullName != null && registerdata.Email != null && registerdata.UserName != null && registerdata.Password != null)
            {
                byte[] data = System.Text.Encoding.ASCII.GetBytes(registerdata.Password);
                data = new System.Security.Cryptography.SHA256Managed().ComputeHash(data);
                String hash = System.Text.Encoding.ASCII.GetString(data);
                var newUser = new account()
                {
                    FullName = registerdata.FullName,
                    Email = registerdata.Email,
                    UserName = registerdata.UserName,
                    Password = hash,
                };
                _context.accounts.Add(newUser);
                _context.SaveChanges();
               
            }
            return View();
        }
     
        [HttpPost]
        public IActionResult Login(account registerdata)
        {

            if (registerdata.Password != null && registerdata.UserName != null)
            {
                var users = _context.accounts.ToList();
                foreach (var user in users)
                {
                    byte[] data = System.Text.Encoding.ASCII.GetBytes(registerdata.Password);
                    data = new System.Security.Cryptography.SHA256Managed().ComputeHash(data);
                    String hash = System.Text.Encoding.ASCII.GetString(data);

                    if (user.UserName.Equals(registerdata.UserName) && user.Password.Equals(hash))
                    {
                        return View("Indexhome");
                    }
                    else { 
                       
                    }
                   

                }
            }
            ModelState.AddModelError("Password", "The Username or Password is incorrect");
            return View();
        }

        
        
        public override bool Equals(object? obj)
        {
            return obj is account_controll controll &&
                   EqualityComparer<AppDbContext>.Default.Equals(_context, controll._context);
        }
    }
}
